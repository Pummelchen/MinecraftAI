# Pummelchen Tropical Worldgen

This datapack overrides the Terralith/Lithostitched overworld biome parameter list for the Pummelchen live servers. It is installed by Safe World Reset before the new world is generated.

## Biome tuning

The current tuning is based on the unmodified Terralith `overworld.json` shipped in `Terralith_26.1_v2.6.1_Neoforge.jar`. Each preferred biome below is set to exactly **5x** its original parameter-cell count. Original preferred-biome cells are preserved, and added cells are selected from nearby safe surface-land climate cells.

Protected terrain families are not converted: oceans, rivers, beaches, swamps, caves, deserts, badlands, frozen/snow-only cells, volcanic/basalt/caldera terrain, and other non-surface cells.

## Exact 5x counts

| Biome | Original | Tuned |
| --- | ---: | ---: |
| `minecraft:bamboo_jungle` | 19 | 95 |
| `minecraft:jungle` | 17 | 85 |
| `minecraft:sparse_jungle` | 30 | 150 |
| `terralith:tropical_jungle` | 12 | 60 |
| `terralith:rocky_jungle` | 21 | 105 |
| `terralith:jungle_mountains` | 4 | 20 |
| `terralith:amethyst_rainforest` | 24 | 120 |
| `minecraft:cherry_grove` | 6 | 30 |
| `terralith:sakura_grove` | 34 | 170 |
| `terralith:sakura_valley` | 5 | 25 |
| `terralith:snowy_cherry_grove` | 7 | 35 |
| `terralith:lavender_forest` | 5 | 25 |
| `terralith:lavender_valley` | 2 | 10 |
| `terralith:orchid_swamp` | 4 | 20 |

Preferred families remain grouped as tropical/jungle, cherry/sakura, and purple flower/tree biomes so they can appear near each other more often after a Safe World Reset.

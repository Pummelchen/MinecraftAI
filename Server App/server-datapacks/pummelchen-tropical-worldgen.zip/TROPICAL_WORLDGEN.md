# Pummelchen Tropical Worldgen

This datapack overrides Terralith/Lithostitched overworld biome parameters for the Pummelchen live servers.

## Biome tuning

Minecraft multi-noise biome sources do not expose simple numeric weights. The requested 10x effect is implemented by widening climate coverage: additional mild/warm land cells are converted into the preferred biome families, while oceans, rivers, beaches, swamps, caves, deserts, badlands, frozen/snow-only cells, and volcanic/basalt cells are preserved.

Preferred biome families are interleaved in the same broad climate neighborhood so they frequently border each other after a Safe World Reset:

- Tropical bamboo/jungle: `minecraft:bamboo_jungle`, `minecraft:jungle`, `minecraft:sparse_jungle`, `terralith:tropical_jungle`, `terralith:rocky_jungle`, `terralith:jungle_mountains`, `terralith:amethyst_rainforest`
- Cherry/sakura forests: `minecraft:cherry_grove`, `terralith:sakura_grove`, `terralith:sakura_valley`, `terralith:snowy_cherry_grove`
- Purple trees/flowers: `terralith:lavender_forest`, `terralith:lavender_valley`, `terralith:amethyst_rainforest`, `terralith:orchid_swamp`

## Specific purple biome guarantee

The following Terralith biome IDs are explicitly held at or above 10x their original estimated parameter-list counts:

- `terralith:lavender_forest`: at least 50 entries
- `terralith:lavender_valley`: at least 50 entries
- `terralith:amethyst_rainforest`: at least 550 entries

Current tuning metadata is embedded in `data/minecraft/worldgen/multi_noise_biome_source_parameter_list/overworld.json` under `pummelchen:tuning`.

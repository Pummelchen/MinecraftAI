# Pummelchen Tropical Worldgen

This datapack overrides Terralith/Lithostitched overworld biome parameters for the Pummelchen live servers.

## Biome tuning

Minecraft multi-noise biome sources do not expose simple numeric weights. The requested biome increase is implemented by widening climate coverage: additional mild/warm land cells are converted into the preferred biome families, while oceans, rivers, beaches, swamps, caves, deserts, badlands, frozen/snow-only cells, and volcanic/basalt cells are preserved.

Preferred biome families are interleaved in the same broad climate neighborhood so they frequently border each other after a Safe World Reset:

- Tropical bamboo/jungle: `minecraft:bamboo_jungle`, `minecraft:jungle`, `minecraft:sparse_jungle`, `terralith:tropical_jungle`, `terralith:rocky_jungle`, `terralith:jungle_mountains`, `terralith:amethyst_rainforest`
- Cherry/sakura forests: `minecraft:cherry_grove`, `terralith:sakura_grove`, `terralith:sakura_valley`, `terralith:snowy_cherry_grove`
- Purple trees/flowers: `terralith:lavender_forest`, `terralith:lavender_valley`, `terralith:amethyst_rainforest`, `terralith:orchid_swamp`

## Specific purple biome coverage

The packed parameter-list counts are audited and intentionally explicit:

- `terralith:lavender_forest`: 50 entries
- `terralith:lavender_valley`: 50 entries
- `terralith:amethyst_rainforest`: 550 entries

`terralith:amethyst_rainforest` is higher because it belongs to both the tropical rainforest family and the purple biome family. Its recorded before-count is 86, so a strict 10x target would be 860 entries. The current datapack does not claim that exact 10x value because reaching it without a broader generator pass would require overwriting protected terrain families or reducing other requested favorite biomes.

Current tuning metadata is embedded in `data/minecraft/worldgen/multi_noise_biome_source_parameter_list/overworld.json` under `pummelchen:tuning`.
